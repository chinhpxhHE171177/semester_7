import { StyleSheet, Text, TouchableOpacity } from 'react-native';

export default function LandItem({ land, onPress }) {
    return (
        <TouchableOpacity style={styles.container} onPress={onPress}>
            <Text style={styles.name}>{land.name}</Text>
            <Text style={styles.location}>{land.location}</Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#FFFFFF',
        padding: 15,
        borderRadius: 10,
        marginBottom: 10,
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        shadowRadius: 2,
    },
    name: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#2E7D32', // Màu xanh lá cây đậm
    },
    location: {
        fontSize: 14,
        color: '#424242',
        marginTop: 5,
    },
});