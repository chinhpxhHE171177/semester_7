import AsyncStorage from '@react-native-async-storage/async-storage';

const LAND_KEY = 'lands';

export const getLands = async () => {
    try {
        const jsonValue = await AsyncStorage.getItem(LAND_KEY);
        return jsonValue ? JSON.parse(jsonValue) : [];
    } catch (e) {
        console.error('Error loading lands:', e);
        return [];
    }
};

export const saveLand = async (land) => {
    try {
        const lands = await getLands();
        const updatedLands = [...lands, land];
        await AsyncStorage.setItem(LAND_KEY, JSON.stringify(updatedLands));
    } catch (e) {
        console.error('Error saving land:', e);
    }
};

export const updateLand = async (updatedLand) => {
    try {
        const lands = await getLands();
        const updatedLands = lands.map(land => (land.id === updatedLand.id ? updatedLand : land));
        await AsyncStorage.setItem(LAND_KEY, JSON.stringify(updatedLands));
    } catch (e) {
        console.error('Error updating land:', e);
    }
};

export const deleteLand = async (id) => {
    try {
        const lands = await getLands();
        const updatedLands = lands.filter(land => land.id !== id);
        await AsyncStorage.setItem(LAND_KEY, JSON.stringify(updatedLands));
        return updatedLands;
    } catch (e) {
        console.error('Error deleting land:', e);
    }
};