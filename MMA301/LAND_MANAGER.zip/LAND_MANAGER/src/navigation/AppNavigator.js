import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import AddEditLandScreen from '../screens/AddLandScreen'; // Sửa tên file
import LandDetailScreen from '../screens/LandDetailScreen';
import MapScreen from '../screens/MapScreen';

const Stack = createStackNavigator();

export default function AppNavigator() {
    return (
        <Stack.Navigator initialRouteName="Home">
            <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'Land Manager' }} />
            <Stack.Screen name="AddEditLand" component={AddEditLandScreen} options={{ title: 'Thêm/Sửa mảnh đất' }} />
            <Stack.Screen name="LandDetail" component={LandDetailScreen} options={{ title: 'Chi tiết mảnh đất' }} />
            <Stack.Screen name="Map" component={MapScreen} options={{ title: 'Bản đồ' }} />
        </Stack.Navigator>
    );
}