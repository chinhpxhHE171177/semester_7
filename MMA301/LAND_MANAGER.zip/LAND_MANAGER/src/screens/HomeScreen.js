import { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TextInput, TouchableOpacity, Animated, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialIcons';
import LandItem from '../components/LandItem';
import { getLands } from '../services/storage';

export default function HomeScreen({ navigation }) {
    const [lands, setLands] = useState([]);
    const [search, setSearch] = useState('');
    const [fadeAnim] = useState(new Animated.Value(0)); // Animation cho header

    useEffect(() => {
        const loadLands = async () => {
            const storedLands = await getLands();
            setLands(storedLands);
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 1000,
                useNativeDriver: true,
            }).start();
        };
        loadLands();
    }, []);

    const filteredLands = lands.filter(land =>
        land.name.toLowerCase().includes(search.toLowerCase()) ||
        land.location.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <View style={styles.container}>
            <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />
            <Animated.View style={[styles.header, { opacity: fadeAnim }]}>
                <LinearGradient colors={['#2E7D32', '#4CAF50']} style={styles.headerGradient}>
                    <Text style={styles.title}>Land Manager</Text>
                </LinearGradient>
            </Animated.View>
            <View style={styles.searchContainer}>
                <Icon name="search" size={24} color="#757575" style={styles.searchIcon} />
                <TextInput
                    style={styles.searchInput}
                    placeholder="Tìm theo tên hoặc vị trí"
                    placeholderTextColor="#757575"
                    value={search}
                    onChangeText={setSearch}
                />
            </View>
            <View style={styles.buttonContainer}>
                <TouchableOpacity
                    style={styles.button}
                    onPress={() => navigation.navigate('AddEditLand', { setLands })}
                >
                    <Icon name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.buttonText}>Thêm mảnh đất</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={[styles.button, styles.mapButton]}
                    onPress={() => navigation.navigate('Map', { lands })}
                >
                    <Icon name="map" size={20} color="#FFFFFF" />
                    <Text style={styles.buttonText}>Xem bản đồ</Text>
                </TouchableOpacity>
            </View>
            <FlatList
                data={filteredLands}
                keyExtractor={item => item.id}
                renderItem={({ item }) => (
                    <LandItem
                        land={item}
                        onPress={() => navigation.navigate('LandDetail', { land: item, setLands })}
                    />
                )}
                contentContainerStyle={styles.listContent}
                ListEmptyComponent={<Text style={styles.emptyText}>Chưa có mảnh đất nào</Text>}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#E8F5E9',
    },
    header: {
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
        overflow: 'hidden',
    },
    headerGradient: {
        paddingVertical: 30,
        paddingHorizontal: 20,
    },
    title: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textAlign: 'center',
        textShadowColor: '#000',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
    },
    searchContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 20,
        paddingTop: 20,
    },
    searchIcon: {
        position: 'absolute',
        left: 30,
        zIndex: 1,
    },
    searchInput: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 12,
        paddingLeft: 40,
        fontSize: 16,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingHorizontal: 20,
        paddingVertical: 15,
    },
    button: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#4CAF50',
        paddingVertical: 12,
        paddingHorizontal: 15,
        borderRadius: 10,
        flex: 1,
        marginHorizontal: 5,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    mapButton: {
        backgroundColor: '#388E3C',
    },
    buttonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: '600',
        marginLeft: 5,
    },
    listContent: {
        paddingHorizontal: 20,
        paddingBottom: 20,
    },
    emptyText: {
        fontSize: 16,
        color: '#757575',
        textAlign: 'center',
        marginTop: 20,
    },
});