// import { StyleSheet, View, Text, Platform } from 'react-native';
// import MapView, { Marker } from 'react-native-maps';
// import { GoogleMap, LoadScript } from '@react-google-maps/api';

// export default function MapScreen({ route }) {
//     const { lands } = route.params;

//     if (Platform.OS === 'web') {
//         return (
//             <View style={styles.container}>
//                 <LoadScript googleMapsApiKey="YOUR_API_KEY">
//                     <GoogleMap
//                         mapContainerStyle={styles.map}
//                         center={{ lat: 10.7769, lng: 106.7009 }}
//                         zoom={10}
//                     >
//                         {lands.map(land => (
//                             <Marker
//                                 key={land.id}
//                                 position={{ lat: 10.7769 + Math.random() * 0.01, lng: 106.7009 + Math.random() * 0.01 }}
//                                 title={land.name}
//                             />
//                         ))}
//                     </GoogleMap>
//                 </LoadScript>
//             </View>
//         );
//     }

//     return (
//         <View style={styles.container}>
//             <MapView
//                 style={styles.map}
//                 initialRegion={{
//                     latitude: 10.7769,
//                     longitude: 106.7009,
//                     latitudeDelta: 0.0922,
//                     longitudeDelta: 0.0421,
//                 }}
//             >
//                 {lands.map(land => (
//                     <Marker
//                         key={land.id}
//                         coordinate={{ latitude: 10.7769 + Math.random() * 0.01, longitude: 106.7009 + Math.random() * 0.01 }}
//                         title={land.name}
//                         description={`${land.price} - ${land.location}`}
//                     />
//                 ))}
//             </MapView>
//         </View>
//     );
// }

// const styles = StyleSheet.create({
//     container: { flex: 1 },
//     map: { flex: 1 },
// });


import React from 'react';
import { StyleSheet, View } from 'react-native';
import MapView, { Marker } from 'react-native-maps';

export default function MapScreen({ route }) {
    const { lands } = route.params || { lands: [] };

    return (
        <View style={styles.container}>
            <MapView
                style={styles.map}
                initialRegion={{
                    latitude: 10.7769,
                    longitude: 106.7009,
                    latitudeDelta: 0.0922,
                    longitudeDelta: 0.0421,
                }}
            >
                {lands.map((land) => (
                    <Marker
                        key={land.id}
                        coordinate={{
                            latitude: land.latitude || 10.7769 + Math.random() * 0.01,
                            longitude: land.longitude || 106.7009 + Math.random() * 0.01,
                        }}
                        title={land.name}
                        description={`${land.price} - ${land.location}`}
                    />
                ))}
            </MapView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },
    map: { flex: 1 },
});