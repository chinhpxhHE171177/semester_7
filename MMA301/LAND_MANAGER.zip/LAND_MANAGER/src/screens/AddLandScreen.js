// import { useState } from 'react';
// import { StyleSheet, View, Text, TextInput, TouchableOpacity, StatusBar } from 'react-native';
// import { saveLand, updateLand } from '../services/storage';

// export default function AddEditLandScreen({ route, navigation }) {
//     const { land, setLands } = route.params || {};
//     const [name, setName] = useState(land?.name || '');
//     const [price, setPrice] = useState(land?.price || '');
//     const [location, setLocation] = useState(land?.location || '');
//     const [latitude, setLatitude] = useState(land?.latitude?.toString() || '');
//     const [longitude, setLongitude] = useState(land?.longitude?.toString() || '');

//     const handleSave = async () => {
//         const newLand = {
//             id: land?.id || Date.now().toString(),
//             name,
//             price,
//             location,
//             latitude: parseFloat(latitude),
//             longitude: parseFloat(longitude),
//         };

//         if (land) {
//             await updateLand(newLand);
//             setLands(prev => prev.map(l => (l.id === newLand.id ? newLand : l)));
//         } else {
//             await saveLand(newLand);
//             setLands(prev => [...prev, newLand]);
//         }
//         navigation.goBack();
//     };

//     return (
//         <View style={styles.container}>
//             <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />
//             <View style={styles.header}>
//                 <Text style={styles.title}>{land ? 'Sửa mảnh đất' : 'Thêm mảnh đất'}</Text>
//             </View>
//             <View style={styles.formContainer}>
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Tên mảnh đất"
//                     placeholderTextColor="#757575"
//                     value={name}
//                     onChangeText={setName}
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Giá (ví dụ: 500 triệu)"
//                     placeholderTextColor="#757575"
//                     value={price}
//                     onChangeText={setPrice}
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Vị trí"
//                     placeholderTextColor="#757575"
//                     value={location}
//                     onChangeText={setLocation}
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Vĩ độ"
//                     placeholderTextColor="#757575"
//                     value={latitude}
//                     onChangeText={setLatitude}
//                     keyboardType="numeric"
//                 />
//                 <TextInput
//                     style={styles.input}
//                     placeholder="Kinh độ"
//                     placeholderTextColor="#757575"
//                     value={longitude}
//                     onChangeText={setLongitude}
//                     keyboardType="numeric"
//                 />
//                 <TouchableOpacity
//                     style={styles.saveButton}
//                     onPress={handleSave}
//                 >
//                     <Text style={styles.buttonText}>{land ? 'Cập nhật' : 'Thêm'}</Text>
//                 </TouchableOpacity>
//             </View>
//         </View>
//     );
// }

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#F5F5F5',
//     },
//     header: {
//         backgroundColor: '#2E7D32',
//         paddingVertical: 20,
//         paddingHorizontal: 20,
//         borderBottomLeftRadius: 20,
//         borderBottomRightRadius: 20,
//         elevation: 5,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.3,
//         shadowRadius: 4,
//     },
//     title: {
//         fontSize: 26,
//         fontWeight: 'bold',
//         color: '#FFFFFF',
//         textAlign: 'center',
//     },
//     formContainer: {
//         padding: 20,
//     },
//     input: {
//         backgroundColor: '#FFFFFF',
//         borderRadius: 10,
//         padding: 12,
//         fontSize: 16,
//         marginBottom: 15,
//         elevation: 2,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 1 },
//         shadowOpacity: 0.2,
//         shadowRadius: 2,
//     },
//     saveButton: {
//         backgroundColor: '#4CAF50',
//         paddingVertical: 12,
//         borderRadius: 8,
//         elevation: 3,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.2,
//         shadowRadius: 3,
//     },
//     buttonText: {
//         color: '#FFFFFF',
//         fontSize: 16,
//         fontWeight: '600',
//         textAlign: 'center',
//     },
// });


import { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, ScrollView, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { saveLand, updateLand } from '../services/storage';

export default function AddEditLandScreen({ route, navigation }) {
    const { land, setLands } = route.params || {};
    const [name, setName] = useState(land?.name || '');
    const [price, setPrice] = useState(land?.price || '');
    const [location, setLocation] = useState(land?.location || '');
    const [latitude, setLatitude] = useState(land?.latitude?.toString() || '');
    const [longitude, setLongitude] = useState(land?.longitude?.toString() || '');

    const handleSave = async () => {
        const newLand = {
            id: land?.id || Date.now().toString(),
            name,
            price,
            location,
            latitude: parseFloat(latitude),
            longitude: parseFloat(longitude),
        };

        if (land) {
            await updateLand(newLand);
            setLands(prev => prev.map(l => (l.id === newLand.id ? newLand : l)));
        } else {
            await saveLand(newLand);
            setLands(prev => [...prev, newLand]);
        }
        navigation.goBack();
    };

    return (
        <View style={styles.container}>
            <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />
            <LinearGradient colors={['#2E7D32', '#4CAF50']} style={styles.header}>
                <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                    <Icon name="arrow-back" size={24} color="#FFFFFF" />
                </TouchableOpacity>
                <Text style={styles.title}>{land ? 'Sửa mảnh đất' : 'Thêm mảnh đất'}</Text>
            </LinearGradient>
            <ScrollView contentContainerStyle={styles.formContainer}>
                <View style={styles.inputContainer}>
                    <Icon name="home" size={20} color="#2E7D32" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Tên mảnh đất"
                        placeholderTextColor="#757575"
                        value={name}
                        onChangeText={setName}
                    />
                </View>
                <View style={styles.inputContainer}>
                    <Icon name="attach-money" size={20} color="#2E7D32" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Giá (ví dụ: 500 triệu)"
                        placeholderTextColor="#757575"
                        value={price}
                        onChangeText={setPrice}
                    />
                </View>
                <View style={styles.inputContainer}>
                    <Icon name="location-on" size={20} color="#2E7D32" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Vị trí"
                        placeholderTextColor="#757575"
                        value={location}
                        onChangeText={setLocation}
                    />
                </View>
                <View style={styles.inputContainer}>
                    <Icon name="latitude" size={20} color="#2E7D32" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Vĩ độ"
                        placeholderTextColor="#757575"
                        value={latitude}
                        onChangeText={setLatitude}
                        keyboardType="numeric"
                    />
                </View>
                <View style={styles.inputContainer}>
                    <Icon name="longitude" size={20} color="#2E7D32" style={styles.inputIcon} />
                    <TextInput
                        style={styles.input}
                        placeholder="Kinh độ"
                        placeholderTextColor="#757575"
                        value={longitude}
                        onChangeText={setLongitude}
                        keyboardType="numeric"
                    />
                </View>
                <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
                    <Icon name="save" size={20} color="#FFFFFF" />
                    <Text style={styles.buttonText}>{land ? 'Cập nhật' : 'Thêm'}</Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#E8F5E9',
    },
    header: {
        paddingVertical: 20,
        paddingHorizontal: 20,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
        elevation: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    backButton: {
        position: 'absolute',
        left: 20,
        top: 25,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textAlign: 'center',
        textShadowColor: '#000',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
    },
    formContainer: {
        padding: 20,
    },
    inputContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 15,
    },
    inputIcon: {
        position: 'absolute',
        left: 10,
        zIndex: 1,
    },
    input: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        borderRadius: 10,
        padding: 12,
        paddingLeft: 40,
        fontSize: 16,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
    },
    saveButton: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#4CAF50',
        paddingVertical: 12,
        borderRadius: 10,
        elevation: 4,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    buttonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: '600',
        marginLeft: 5,
    },
});