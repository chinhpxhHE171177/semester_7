// import { StyleSheet, View, Text, TouchableOpacity, StatusBar } from 'react-native';
// import { deleteLand } from '../services/storage';

// export default function LandDetailScreen({ route, navigation }) {
//     const { land, setLands } = route.params;

//     const handleDelete = async () => {
//         const updatedLands = await deleteLand(land.id);
//         setLands(updatedLands);
//         navigation.goBack();
//     };

//     return (
//         <View style={styles.container}>
//             <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />
//             <View style={styles.header}>
//                 <Text style={styles.title}>{land.name}</Text>
//             </View>
//             <View style={styles.content}>
//                 <View style={styles.infoCard}>
//                     <Text style={styles.label}>Giá:</Text>
//                     <Text style={styles.value}>{land.price}</Text>
//                     <Text style={styles.label}>Vị trí:</Text>
//                     <Text style={styles.value}>{land.location}</Text>
//                     <Text style={styles.label}>Vĩ độ:</Text>
//                     <Text style={styles.value}>{land.latitude || 'Chưa có'}</Text>
//                     <Text style={styles.label}>Kinh độ:</Text>
//                     <Text style={styles.value}>{land.longitude || 'Chưa có'}</Text>
//                 </View>
//                 <View style={styles.buttonContainer}>
//                     <TouchableOpacity
//                         style={styles.editButton}
//                         onPress={() => navigation.navigate('AddEditLand', { land, setLands })}
//                     >
//                         <Text style={styles.buttonText}>Sửa</Text>
//                     </TouchableOpacity>
//                     <TouchableOpacity
//                         style={styles.deleteButton}
//                         onPress={handleDelete}
//                     >
//                         <Text style={styles.buttonText}>Xóa</Text>
//                     </TouchableOpacity>
//                 </View>
//             </View>
//         </View>
//     );
// }

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: '#F5F5F5',
//     },
//     header: {
//         backgroundColor: '#2E7D32',
//         paddingVertical: 20,
//         paddingHorizontal: 20,
//         borderBottomLeftRadius: 20,
//         borderBottomRightRadius: 20,
//         elevation: 5,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.3,
//         shadowRadius: 4,
//     },
//     title: {
//         fontSize: 26,
//         fontWeight: 'bold',
//         color: '#FFFFFF',
//         textAlign: 'center',
//     },
//     content: {
//         flex: 1,
//         padding: 20,
//     },
//     infoCard: {
//         backgroundColor: '#FFFFFF',
//         borderRadius: 10,
//         padding: 15,
//         elevation: 2,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 1 },
//         shadowOpacity: 0.2,
//         shadowRadius: 2,
//         marginBottom: 20,
//     },
//     label: {
//         fontSize: 16,
//         fontWeight: '600',
//         color: '#2E7D32',
//         marginTop: 10,
//     },
//     value: {
//         fontSize: 16,
//         color: '#424242',
//         marginBottom: 5,
//     },
//     buttonContainer: {
//         flexDirection: 'row',
//         justifyContent: 'space-between',
//     },
//     editButton: {
//         backgroundColor: '#4CAF50',
//         paddingVertical: 12,
//         paddingHorizontal: 20,
//         borderRadius: 8,
//         flex: 1,
//         marginRight: 10,
//         elevation: 3,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.2,
//         shadowRadius: 3,
//     },
//     deleteButton: {
//         backgroundColor: '#D32F2F',
//         paddingVertical: 12,
//         paddingHorizontal: 20,
//         borderRadius: 8,
//         flex: 1,
//         elevation: 3,
//         shadowColor: '#000',
//         shadowOffset: { width: 0, height: 2 },
//         shadowOpacity: 0.2,
//         shadowRadius: 3,
//     },
//     buttonText: {
//         color: '#FFFFFF',
//         fontSize: 16,
//         fontWeight: '600',
//         textAlign: 'center',
//     },
// });


import { StyleSheet, View, Text, TouchableOpacity, Share, StatusBar } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { deleteLand } from '../services/storage';

export default function LandDetailScreen({ route, navigation }) {
    const { land, setLands } = route.params;

    const handleDelete = async () => {
        const updatedLands = await deleteLand(land.id);
        setLands(updatedLands);
        navigation.goBack();
    };

    const handleShare = async () => {
        try {
            await Share.share({
                message: `Mảnh đất: ${land.name}\nGiá: ${land.price}\nVị trí: ${land.location}\nTọa độ: (${land.latitude}, ${land.longitude})`,
            });
        } catch (error) {
            console.error('Error sharing:', error);
        }
    };

    return (
        <View style={styles.container}>
            <StatusBar barStyle="light-content" backgroundColor="#2E7D32" />
            <LinearGradient colors={['#2E7D32', '#4CAF50']} style={styles.header}>
                <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
                    <Icon name="arrow-back" size={24} color="#FFFFFF" />
                </TouchableOpacity>
                <Text style={styles.title}>{land.name}</Text>
            </LinearGradient>
            <View style={styles.content}>
                <View style={styles.infoCard}>
                    <Text style={styles.label}>Giá:</Text>
                    <Text style={styles.value}>{land.price}</Text>
                    <Text style={styles.label}>Vị trí:</Text>
                    <Text style={styles.value}>{land.location}</Text>
                    <Text style={styles.label}>Vĩ độ:</Text>
                    <Text style={styles.value}>{land.latitude || 'Chưa có'}</Text>
                    <Text style={styles.label}>Kinh độ:</Text>
                    <Text style={styles.value}>{land.longitude || 'Chưa có'}</Text>
                    <Text style={styles.label}>Ngày thêm:</Text>
                    <Text style={styles.value}>{new Date(parseInt(land.id)).toLocaleDateString()}</Text>
                </View>
                <View style={styles.buttonContainer}>
                    <TouchableOpacity style={styles.shareButton} onPress={handleShare}>
                        <Icon name="share" size={20} color="#FFFFFF" />
                        <Text style={styles.buttonText}>Chia sẻ</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.editButton}
                        onPress={() => navigation.navigate('AddEditLand', { land, setLands })}
                    >
                        <Icon name="edit" size={20} color="#FFFFFF" />
                        <Text style={styles.buttonText}>Sửa</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
                        <Icon name="delete" size={20} color="#FFFFFF" />
                        <Text style={styles.buttonText}>Xóa</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#E8F5E9',
    },
    header: {
        paddingVertical: 20,
        paddingHorizontal: 20,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20,
        elevation: 5,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
    },
    backButton: {
        position: 'absolute',
        left: 20,
        top: 25,
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textAlign: 'center',
        textShadowColor: '#000',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
    },
    content: {
        flex: 1,
        padding: 20,
    },
    infoCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 12,
        padding: 20,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.2,
        shadowRadius: 3,
        marginBottom: 20,
    },
    label: {
        fontSize: 16,
        fontWeight: '600',
        color: '#2E7D32',
        marginTop: 10,
    },
    value: {
        fontSize: 16,
        color: '#424242',
        marginBottom: 5,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    shareButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#0288D1',
        paddingVertical: 12,
        paddingHorizontal: 15,
        borderRadius: 10,
        flex: 1,
        marginHorizontal: 5,
        elevation: 4,
    },
    editButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#4CAF50',
        paddingVertical: 12,
        paddingHorizontal: 15,
        borderRadius: 10,
        flex: 1,
        marginHorizontal: 5,
        elevation: 4,
    },
    deleteButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#D32F2F',
        paddingVertical: 12,
        paddingHorizontal: 15,
        borderRadius: 10,
        flex: 1,
        marginHorizontal: 5,
        elevation: 4,
    },
    buttonText: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: '600',
        marginLeft: 5,
    },
});