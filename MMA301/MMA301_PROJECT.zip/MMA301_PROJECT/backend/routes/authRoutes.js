// authRoutes.js
import express from 'express';
import {
    register,
    login,
    getAlls,
    getUserByID,
    updateProfile,
    changePassword,
    googleAuth,
    googleAuthCallback,
    verifyGoogleToken
} from '../controllers/authController.js';

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/users', getAlls);
router.get('/user/:id', getUserByID);
// 📝 Cập nhật thông tin người dùng
router.put('/profile/:id', updateProfile);

// 🔐 Thay đổi mật khẩu
router.put('/change-password/:id', changePassword);

// Rutas de autenticación con Google
router.get('/google', googleAuth);
router.get('/google/callback', googleAuthCallback);
router.post('/google/token', verifyGoogleToken);

export default router;

