import images from "./images";
import icons from "./icons";
import colors from "./colors";
export {
    images,
    icons,
    colors
}