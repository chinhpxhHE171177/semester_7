export default {
    puppy: require('../../assets/images/puppy.png'),
    login_logo: require('../../assets/images/login_logo.png'),
    caregiver1: require('../../assets/images/caregiver1.png'),
    caregiver2: require('../../assets/images/caregiver2.png'),
};
