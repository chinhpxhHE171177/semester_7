import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import { icons, colors } from '../constants';

const ForgotPasswordScreen = ({ navigation }) => {
    const [email, setEmail] = useState('');

    const handleResetPassword = () => {
        if (!email) {
            Alert.alert('Error', 'Please enter your email');
            return;
        }
        Alert.alert('Success', 'A reset link has been sent to your email.');
        navigation.goBack();
    };

    return (
        <View style={styles.container}>
            {/* Back Button */}
            <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButtonContainer}>
                <Image source={icons.left_arrow} style={styles.backButton} />
            </TouchableOpacity>

            <Text style={styles.heading}>Forgot Password?</Text>
            <Text style={styles.subheading}>Enter your email to reset your password</Text>

            <TextInput
                style={styles.input}
                placeholder="Email"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
            />

            <TouchableOpacity style={styles.button} onPress={handleResetPassword}>
                <Text style={styles.buttonText}>Send Reset Link</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.white,
        padding: 20,
        justifyContent: 'center',
        alignItems: 'center'
    },
    backButtonContainer: {
        position: 'absolute',
        top: 30,
        left: 20,
        zIndex: 1,
    },
    backButton: {
        width: 30,
        height: 30,
    },
    heading: {
        fontSize: 24,
        fontWeight: 'bold',
        color: colors.purple_color,
        marginBottom: 10,
    },
    subheading: {
        fontSize: 16,
        color: colors.gray,
        marginBottom: 20,
    },
    input: {
        width: '90%',
        height: 50,
        borderColor: colors.purple_color,
        borderWidth: 1,
        borderRadius: 10,
        paddingHorizontal: 15,
        marginBottom: 20,
        backgroundColor: colors.white,
    },
    button: {
        backgroundColor: colors.purple_color,
        borderRadius: 25,
        height: 50,
        width: '70%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    buttonText: {
        color: colors.white,
        fontSize: 16,
        fontWeight: 'bold',
    }
});

export default ForgotPasswordScreen;
