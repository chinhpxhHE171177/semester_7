// import React, { useState, useEffect } from 'react';
// import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
// import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { loginUser } from '../services/api';
// import Icon from 'react-native-vector-icons/FontAwesome5';
// import { images, colors, icons } from '../constants';


// GoogleSignin.configure({
//   webClientId: process.env.CLIENT_ID, // Usar tu webClientId
//   offlineAccess: true,
// });


// const LoginScreen = ({ navigation }) => {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [loading, setLoading] = useState(false);

//   // Verifica si el usuario ya está autenticado
//   useEffect(() => {
//     const checkUserLoggedIn = async () => {
//       const userToken = await AsyncStorage.getItem('userToken');
//       if (userToken) {
//         navigation.navigate('UITabs');
//       }
//     };

//     checkUserLoggedIn();
//   }, []);

//   const handleLogin = async () => {
//     if (!email || !password) {
//       Alert.alert('Error', 'Please fill all fields');
//       return;
//     }

//     setLoading(true);
//     try {
//       const response = await loginUser({ Email: email, Password: password });

//       // Lưu token và userId vào AsyncStorage
//       await AsyncStorage.setItem('userToken', response.token);
//       await AsyncStorage.setItem('userID', response.userId.toString());
//       await AsyncStorage.setItem('role', response.role);
//       await AsyncStorage.setItem('fullName', response.fullName);
//       await AsyncStorage.setItem('url', response.url);

//       // Alert.alert('Success', 'Login successful!');
//       // navigation.navigate('UITabs', { token: response.token });
//       setLoading(false);
//       navigation.navigate('UITabs', { token: response.token });
//     } catch (error) {
//       setLoading(false);
//       Alert.alert('Error', error);
//     }
//   };

//   const handleGoogleLogin = async () => {
//     setLoading(true);
//     try {
//       await GoogleSignin.hasPlayServices();
//       const userInfo = await GoogleSignin.signIn();

//       // Enviar el token de ID al backend para verificar
//       const response = await axios.post('http://localhost:9999/auth/google/token', {
//         token: userInfo.idToken
//       });

//       const data = response.data;

//       // Guardar información del usuario
//       await AsyncStorage.setItem('userToken', data.token);
//       await AsyncStorage.setItem('userID', data.userId.toString());
//       await AsyncStorage.setItem('role', data.role);
//       await AsyncStorage.setItem('fullName', data.fullName);
//       await AsyncStorage.setItem('url', data.url);

//       setLoading(false);
//       navigation.navigate('UITabs');
//     } catch (error) {
//       setLoading(false);

//       if (error.code === statusCodes.SIGN_IN_CANCELLED) {
//         console.log('Login cancelled');
//       } else if (error.code === statusCodes.IN_PROGRESS) {
//         console.log('Login in progress');
//       } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
//         Alert.alert('Error', 'Google Play Services not available');
//       } else {
//         console.error('Google sign-in error:', error);
//         Alert.alert('Error', 'Login failed: ' + error.toString());
//       }
//     }
//   };

//   return (
//     <View style={styles.container}>
//       <Image source={images.login_logo} style={styles.image} />
//       <Text style={styles.heading}>PETCARE</Text>
//       <Text style={styles.subheading}>Welcome back! Glad to see you again</Text>

//       <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center' }}>
//         <Icon name="envelope" size={15} style={styles.icon} />
//         <TextInput style={styles.input} placeholder="Email" value={email} onChangeText={setEmail} keyboardType="email-address" />
//       </View>

//       <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center' }}>
//         <Icon name="lock" size={15} style={styles.icon} />
//         <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry={true} />
//       </View>

//       <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
//         <Text style={styles.forgotPassword}>Forgot Password?</Text>
//       </TouchableOpacity>

//       {/* <TouchableOpacity style={styles.button} onPress={handleLogin}>
//         <Text style={styles.buttonText}>Login</Text>
//       </TouchableOpacity> */}
//       <TouchableOpacity
//         style={styles.button}
//         onPress={handleLogin}
//         disabled={loading}
//       >
//         <Text style={styles.buttonText}>{loading ? 'Logging in...' : 'Login'}</Text>
//       </TouchableOpacity>

//       {/* <TouchableOpacity style={styles.googleButton}>
//         <Image source={icons.google} style={styles.googleIcon} />
//         <Text style={styles.googleButtonText}>Login with Google</Text>
//       </TouchableOpacity> */}
//       <Text style={styles.divider}>---------- Login other with ----------</Text>

//       <View style={styles.socialButtonsContainer}>
//         <TouchableOpacity
//           style={styles.socialButton}
//           onPress={handleGoogleLogin}
//           disabled={loading}
//         >
//           <Image source={icons.google} style={styles.socialIcon} />
//         </TouchableOpacity>

//         <TouchableOpacity style={styles.socialButton}>
//           <Image source={icons.facebook} style={styles.socialIcon} />
//         </TouchableOpacity>

//         <TouchableOpacity style={styles.socialButton}>
//           <Image source={icons.twitter} style={styles.socialIcon} />
//         </TouchableOpacity>
//       </View>

//       <TouchableOpacity onPress={() => navigation.navigate('Register')}>
//         <Text style={styles.link}>Don't have an account? Register</Text>
//       </TouchableOpacity>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: colors.login_color,
//     padding: 20,
//     justifyContent: 'center',
//     alignItems: 'center'
//   },
//   image: {
//     width: 300,
//     height: 300,
//     marginBottom: 20,
//   },
//   heading: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     color: colors.purple_color,
//     marginBottom: 5,
//   },
//   subheading: {
//     fontSize: 18,
//     color: colors.title,
//     marginBottom: 20,
//   },
//   input: {
//     width: '100%',
//     height: 55,
//     borderColor: colors.purple_color,
//     borderWidth: 1,
//     borderRadius: 10,
//     paddingHorizontal: 18,
//     marginBottom: 18,
//     backgroundColor: colors.white,
//   },
//   inputIcon: {
//     flex: 1,
//     backgroundColor: colors.white,
//     borderColor: colors.purple_color,
//     height: 55,
//     marginEnd: 5,
//     borderWidth: 1,
//     borderRadius: 10,
//     opacity: 0.8,
//     paddingHorizontal: 25,
//     marginBottom: 18,
//     paddingStart: 40,
//   },
//   icon: {
//     position: 'absolute',
//     height: 33,
//     paddingStart: 10,
//     tintColor: colors.title,
//     fontWeight: 'bold',

//   },
//   button: {
//     backgroundColor: colors.purple_color,
//     borderRadius: 25,
//     height: 50,
//     width: '70%',
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginTop: 20,
//     marginBottom: 10,
//   },
//   buttonText: {
//     color: colors.white,
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   registerText: {
//     marginTop: 20,
//     color: colors.title,
//     textDecorationLine: 'underline',
//   },
//   link: {
//     color: colors.purple_color,
//     fontWeight: 'bold',
//     textDecorationLine: 'underline',
//   },
//   googleButton: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     // backgroundColor: colors.white,
//     borderRadius: 25,
//     height: 50,
//     width: '90%', // Responsive trên mọi thiết bị
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginTop: 10,
//     // borderWidth: 1,
//     // borderColor: colors.gray,
//     // shadowColor: "#000",
//     // shadowOffset: { width: 0, height: 2 },
//     // shadowOpacity: 0.2,
//     // shadowRadius: 2,
//     // elevation: 2, // Hiệu ứng đổ bóng trên Android
//   },
//   googleIcon: {
//     width: 20,
//     height: 20,
//     marginRight: 10,
//   },
//   googleButtonText: {
//     color: colors.black,
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
//   forgotPassword: {
//     color: colors.purple_color,
//     fontWeight: 'bold',
//     textDecorationLine: 'underline',
//     textAlign: 'left'
//   },
//   divider: {
//     marginVertical: 15,
//     color: '#888',
//     fontSize: 14,
//   },
//   socialButtonsContainer: {
//     flexDirection: 'row',
//     justifyContent: 'center',
//     marginBottom: 20,
//   },
//   socialButton: {
//     width: 50,
//     height: 50,
//     justifyContent: 'center',
//     alignItems: 'center',
//     marginHorizontal: 10,
//     borderRadius: 25,
//     backgroundColor: '#f5f5f5',
//   },
//   socialIcon: {
//     width: 30,
//     height: 30,
//     resizeMode: 'contain',
//   },
// });

// export default LoginScreen;


import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert, Image, Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loginUser } from '../services/api';
import Icon from 'react-native-vector-icons/FontAwesome5';
import { images, colors, icons } from '../constants';
import axios from 'axios';

// Kiểm tra xem Google Sign-In có khả dụng không
const checkGoogleSignInAvailability = () => {
  if (Platform.OS === 'web') {
    return false; // Không hỗ trợ trên web
  }

  try {
    // Kiểm tra module có tồn tại không
    const GoogleSigninImport = require('@react-native-google-signin/google-signin');
    return true;
  } catch (error) {
    console.warn('Google Sign-In không khả dụng:', error.message);
    return false;
  }
};

// Biến global để kiểm tra khả dụng của Google Sign-In
const isGoogleSignInAvailable = checkGoogleSignInAvailability();

// Chỉ import GoogleSignin khi module khả dụng
let GoogleSignin, statusCodes;
if (isGoogleSignInAvailable) {
  try {
    const GoogleSigninImport = require('@react-native-google-signin/google-signin');
    GoogleSignin = GoogleSigninImport.GoogleSignin;
    statusCodes = GoogleSigninImport.statusCodes;

    // Chỉ cấu hình GoogleSignin khi chắc chắn đã import thành công
    GoogleSignin.configure({
      webClientId: '886355572484-svvnq82q86687jeheke4631h0h5nehhd.apps.googleusercontent.com',
      offlineAccess: true,
    });
  } catch (error) {
    console.warn('Không thể cấu hình Google Sign-In:', error.message);
  }
}

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({
    email: '',
    password: '',
    general: ''
  });

  // Kiểm tra người dùng đã đăng nhập chưa
  useEffect(() => {
    const checkUserLoggedIn = async () => {
      try {
        const userToken = await AsyncStorage.getItem('userToken');
        if (userToken) {
          navigation.navigate('UITabs');
        }
      } catch (error) {
        console.error('Lỗi khi kiểm tra trạng thái đăng nhập:', error);
      }
    };

    checkUserLoggedIn();
  }, []);

  // Kiểm tra định dạng email
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Xóa thông báo lỗi khi người dùng bắt đầu nhập lại
  const clearErrors = () => {
    setErrors({
      email: '',
      password: '',
      general: ''
    });
  };

  const handleLogin = async () => {
    // Xóa lỗi cũ
    clearErrors();

    // Kiểm tra các trường
    let hasError = false;
    const newErrors = {
      email: '',
      password: '',
      general: ''
    };

    // Kiểm tra email
    if (!email) {
      newErrors.email = 'Vui lòng nhập email';
      hasError = true;
    } else if (!isValidEmail(email)) {
      newErrors.email = 'Định dạng email không hợp lệ';
      hasError = true;
    }

    // Kiểm tra mật khẩu
    if (!password) {
      newErrors.password = 'Vui lòng nhập mật khẩu';
      hasError = true;
      // } else if (password.length < 6) {
      //   newErrors.password = 'Mật khẩu phải có ít nhất 6 ký tự';
      //   hasError = true;
    }

    if (hasError) {
      setErrors(newErrors);
      return;
    }

    setLoading(true);
    try {
      const response = await loginUser({ Email: email, Password: password });

      // Lưu token và thông tin người dùng vào AsyncStorage
      await AsyncStorage.setItem('userToken', response.token);
      await AsyncStorage.setItem('userID', response.userId.toString());
      await AsyncStorage.setItem('role', response.role);
      await AsyncStorage.setItem('fullName', response.fullName);
      await AsyncStorage.setItem('url', response.url);

      setLoading(false);
      navigation.navigate('UITabs', { token: response.token });
    } catch (error) {
      setLoading(false);

      // Xử lý lỗi đăng nhập
      if (error.response && error.response.status === 401) {
        setErrors({
          ...newErrors,
          general: 'Email hoặc mật khẩu không chính xác'
        });
      } else if (error.response && error.response.data && error.response.data.message) {
        setErrors({
          ...newErrors,
          general: error.response.data.message
        });
      } else {
        setErrors({
          ...newErrors,
          general: 'Đã xảy ra lỗi khi đăng nhập. Vui lòng thử lại sau.'
        });
      }
      console.error('Login error:', error);
    }
  };

  const handleGoogleLogin = async () => {
    clearErrors();

    // Kiểm tra Google Sign-In có khả dụng không
    if (!isGoogleSignInAvailable) {
      setErrors({
        ...errors,
        general: 'Đăng nhập bằng Google không được hỗ trợ trên thiết bị này. Vui lòng sử dụng đăng nhập bằng email/mật khẩu.'
      });
      return;
    }

    setLoading(true);
    try {
      await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
      const userInfo = await GoogleSignin.signIn();

      // Gửi token ID đến backend để xác minh
      const response = await axios.post('http://localhost:8081/auth/google/token', {
        token: userInfo.idToken
      });

      const data = response.data;

      // Lưu thông tin người dùng
      await AsyncStorage.setItem('userToken', data.token);
      await AsyncStorage.setItem('userID', data.userId.toString());
      await AsyncStorage.setItem('role', data.role);
      await AsyncStorage.setItem('fullName', data.fullName);
      await AsyncStorage.setItem('url', data.url);

      setLoading(false);
      navigation.navigate('UITabs');
    } catch (error) {
      setLoading(false);

      // Xử lý các lỗi Google Sign-In cụ thể
      if (statusCodes && error.code === statusCodes.SIGN_IN_CANCELLED) {
        console.log('Đăng nhập bị hủy');
      } else if (statusCodes && error.code === statusCodes.IN_PROGRESS) {
        console.log('Đăng nhập đang trong tiến trình');
      } else if (statusCodes && error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
        setErrors({
          ...errors,
          general: 'Dịch vụ Google Play không khả dụng'
        });
      } else {
        console.error('Lỗi đăng nhập Google:', error);
        setErrors({
          ...errors,
          general: 'Đăng nhập Google thất bại: ' + (error.message || error.toString())
        });
      }
    }
  };

  // Xác định nút đăng nhập Google có nên bị vô hiệu hóa không
  const isGoogleButtonDisabled = !isGoogleSignInAvailable || loading;

  return (
    <View style={styles.container}>
      <Image source={images.login_logo} style={styles.image} />
      <Text style={styles.heading}>PETCARE</Text>
      <Text style={styles.subheading}>Welcome back! Glad to see you again</Text>

      {errors.general ? <Text style={styles.errorMessage}>{errors.general}</Text> : null}

      <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center' }}>
        <Icon name="envelope" size={15} style={styles.icon} />
        <TextInput
          style={[styles.input, errors.email ? styles.inputError : null]}
          placeholder="Email"
          value={email}
          onChangeText={(text) => {
            setEmail(text);
            if (errors.email) {
              setErrors({ ...errors, email: '' });
            }
          }}
          keyboardType="email-address"
        />
      </View>
      {errors.email ? <Text style={styles.fieldError}>{errors.email}</Text> : null}

      <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center' }}>
        <Icon name="lock" size={15} style={styles.icon} />
        <TextInput
          style={[styles.input, errors.password ? styles.inputError : null]}
          placeholder="Password"
          value={password}
          onChangeText={(text) => {
            setPassword(text);
            if (errors.password) {
              setErrors({ ...errors, password: '' });
            }
          }}
          secureTextEntry={true}
        />
      </View>
      {errors.password ? <Text style={styles.fieldError}>{errors.password}</Text> : null}

      <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
        <Text style={styles.forgotPassword}>Forgot Password?</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.button}
        onPress={handleLogin}
        disabled={loading}
      >
        <Text style={styles.buttonText}>{loading ? 'Đang đăng nhập...' : 'Login'}</Text>
      </TouchableOpacity>

      <Text style={styles.divider}>---------- Login other with ----------</Text>

      <View style={styles.socialButtonsContainer}>
        <TouchableOpacity
          // style={[styles.socialButton, isGoogleButtonDisabled ? styles.socialButtonDisabled : null]}
          style={styles.socialButton}
          onPress={handleGoogleLogin}
        >
          <Image source={icons.google} style={styles.socialIcon} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton}>
          <Image source={icons.facebook} style={styles.socialIcon} />
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton}>
          <Image source={icons.twitter} style={styles.socialIcon} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity onPress={() => navigation.navigate('Register')}>
        <Text style={styles.link}>Don't have an account? Register</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: colors.login_color,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 120,
    height: 120,
    marginBottom: 20
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10
  },
  subheading: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center'
  },
  icon: {
    marginRight: 10,
    color: '#666',
    width: 20,
    textAlign: 'center'
  },
  input: {
    flex: 1,
    height: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#e1e1e1',
    marginBottom: 15
  },
  button: {
    backgroundColor: '#007BFF',
    padding: 15,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
    marginTop: 20,
    marginBottom: 20
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },
  forgotPassword: {
    color: '#007BFF',
    alignSelf: 'flex-end',
    marginBottom: 20
  },
  divider: {
    color: '#666',
    marginVertical: 20
  },
  socialButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20
  },
  socialButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#f5f5f5',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10
  },
  socialButtonDisabled: {
    opacity: 0.5
  },
  socialIcon: {
    width: 25,
    height: 25
  },
  link: {
    color: '#007BFF',
    marginTop: 10
  },
  errorMessage: {
    color: '#FF3B30',
    marginBottom: 10,
    textAlign: 'center',
    width: '100%',
    fontWeight: '500'
  },
  fieldError: {
    color: '#FF3B30',
    fontSize: 12,
    marginTop: -5,
    marginBottom: 5,
    alignSelf: 'flex-start',
    marginLeft: 35
  },
  inputError: {
    borderBottomColor: '#FF3B30'
  }
});

export default LoginScreen;