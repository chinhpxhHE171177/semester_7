import React from 'react'
import { Text } from 'react-native'
import AppNavigator from './navigation/AppNavigation'
export default function App() {
  return (
    <AppNavigator/>
  )
}

