import UITabs from "./UITabs"
export {
    UITabs,
}