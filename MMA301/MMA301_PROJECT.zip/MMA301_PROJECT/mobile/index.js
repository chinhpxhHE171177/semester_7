import { registerRootComponent } from 'expo';
import App from '../mobile/src/App.js';

registerRootComponent(App);