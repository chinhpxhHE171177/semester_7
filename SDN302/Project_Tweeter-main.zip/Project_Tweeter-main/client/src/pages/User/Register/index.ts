import Register from './Register'

export default Register
