import StatusWithChat from './StatusWithChat'

export default StatusWithChat
