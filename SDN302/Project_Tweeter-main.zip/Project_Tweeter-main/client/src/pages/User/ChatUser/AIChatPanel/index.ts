import AIChatPanel from './AIChatPanel'

export default AIChatPanel
