import EventWithMessage from './EventWithMessage'

export default EventWithMessage
