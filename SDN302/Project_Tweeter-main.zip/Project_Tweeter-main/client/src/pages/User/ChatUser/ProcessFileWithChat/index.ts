import ProcessFileWithChat from './ProcessFileWithChat'

export default ProcessFileWithChat
