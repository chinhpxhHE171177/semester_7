import HomeSection from './HomeSection'

export default HomeSection
