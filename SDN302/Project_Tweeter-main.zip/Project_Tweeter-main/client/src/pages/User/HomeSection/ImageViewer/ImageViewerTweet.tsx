import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel'
import { Tweets } from '@/types/Tweet.type'
interface Props {
  data: Tweets
}
export default function ImageViewerTweet({ data }: Props) {
  return <div>ImageViewerTweet</div>
}
