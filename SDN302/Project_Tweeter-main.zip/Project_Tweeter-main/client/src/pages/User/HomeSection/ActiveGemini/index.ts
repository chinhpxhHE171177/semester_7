import ActiveGemini from './ActiveGemini'

export default ActiveGemini
