import TwitterCard from './TwitterCard'

export default TwitterCard
