import VerifyEmail from './VerifyEmail'

export default VerifyEmail
