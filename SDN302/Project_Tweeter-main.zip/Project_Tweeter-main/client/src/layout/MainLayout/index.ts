import MainLayout from './MainLayout'

export default MainLayout
