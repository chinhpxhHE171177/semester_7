import { ThemeProvider } from './theme-provider'

export default ThemeProvider
