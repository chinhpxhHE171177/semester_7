import RightPart from './RightPart'

export default RightPart
