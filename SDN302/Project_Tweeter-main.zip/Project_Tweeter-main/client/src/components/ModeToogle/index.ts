import { ModeToggle } from './mode-toggle'

export default ModeToggle
