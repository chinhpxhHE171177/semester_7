import path from 'path'
export const UPLOAD_TEMP_DIR = path.resolve('uploads/temp')
export const UPLOAD_IMAGES_DIR = path.resolve('uploads/Images')

export const UPLOAD_VIDEO_DIR = path.resolve('uploads/video')
export const UPLOAD_VIDEO_HLS_DIR = path.resolve('uploads/video-hls')
