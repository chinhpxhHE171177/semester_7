export const REGEX_USERNAME = /^(?![0-9]+$)[a-zA-Z0-9_]{4,15}$/
