export interface BookmarkTweetReqBody {
  tweet_id: string
}
