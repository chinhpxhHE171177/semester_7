export interface Bookmark {
  _id?: string
  user_id: string
  tweet_id: string
  created_at?: Date
}
 