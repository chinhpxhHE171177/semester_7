import SearchGrowing from './SearchGrowing'

export default SearchGrowing
