import VideoHLSPlayer from './VideoHLSPlayer'

export default VideoHLSPlayer
