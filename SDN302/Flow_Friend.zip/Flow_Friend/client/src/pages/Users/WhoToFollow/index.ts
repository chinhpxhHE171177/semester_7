import WhoToFollow from './WhoToFollow'

export default WhoToFollow
