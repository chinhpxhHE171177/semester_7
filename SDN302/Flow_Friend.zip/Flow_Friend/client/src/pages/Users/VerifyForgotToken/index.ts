import VerifyForgotToken from './VerifyForgotToken'

export default VerifyForgotToken
