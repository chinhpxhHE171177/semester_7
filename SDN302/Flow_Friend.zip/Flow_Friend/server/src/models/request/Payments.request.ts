export interface CreatePaymentResBody {
    subscription_type: string
  }
  