export interface LikeTweetReqBody {
    tweet_id: string
  }
  