import OAuthCallback from './OAuthCallback'

export default OAuthCallback
