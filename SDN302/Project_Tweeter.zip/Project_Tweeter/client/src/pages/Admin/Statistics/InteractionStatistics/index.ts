import InteractionStatistics from './InteractionStatistics'

export default InteractionStatistics