import ContentStatistics from './ContentStatistics'

export default ContentStatistics