import ContentModeration from './ContentModeration'

export default ContentModeration