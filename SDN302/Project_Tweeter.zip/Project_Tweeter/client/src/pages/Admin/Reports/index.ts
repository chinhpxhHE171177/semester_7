import ReportGeneration from './ReportGeneration'

export default ReportGeneration