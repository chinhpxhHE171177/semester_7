import AdminDashboard from './Dashboard'

export default AdminDashboard