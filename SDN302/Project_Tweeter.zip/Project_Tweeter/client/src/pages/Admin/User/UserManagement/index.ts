import UserManagement from './UserManagement'

export default UserManagement