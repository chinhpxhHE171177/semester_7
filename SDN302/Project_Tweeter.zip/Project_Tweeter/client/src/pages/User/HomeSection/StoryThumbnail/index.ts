import StoryThumbnail from './StoryThumbnail'

export default StoryThumbnail