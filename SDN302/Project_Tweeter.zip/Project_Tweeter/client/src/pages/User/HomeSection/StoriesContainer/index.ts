import StoriesContainer from './StoriesContainer'

export default StoriesContainer