import FollowingList from './FollowingList'

export default FollowingList
