import StoryProgressBar from './StoryProgressBar'

export default StoryProgressBar