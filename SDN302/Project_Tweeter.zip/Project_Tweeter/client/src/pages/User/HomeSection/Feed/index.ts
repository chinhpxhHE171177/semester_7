import Feed from "./Feed";

export default Feed