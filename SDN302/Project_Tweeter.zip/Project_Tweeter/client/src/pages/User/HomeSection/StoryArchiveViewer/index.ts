import StoryArchiveViewer from './StoryArchiveViewer'

export default StoryArchiveViewer