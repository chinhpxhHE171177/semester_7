import PaymentHistoryPage from './PaymentHistoryPage'

export default PaymentHistoryPage
