import PaymentDetailPage from './PaymentDetailPage'

export default PaymentDetailPage