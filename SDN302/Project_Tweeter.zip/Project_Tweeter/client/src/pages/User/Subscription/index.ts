import SubscriptionPage from './SubscriptionPage'

export default SubscriptionPage