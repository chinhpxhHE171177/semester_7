import FollowAnyUser from './FollowAnyUser'

export default FollowAnyUser
