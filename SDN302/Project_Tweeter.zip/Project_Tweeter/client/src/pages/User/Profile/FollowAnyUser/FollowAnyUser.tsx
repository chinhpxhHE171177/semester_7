export default function FollowAnyUser() {
  return (
    <div className='h-auto mt-4 mx-3'>
      <p className='text-center'>Who to follow</p>
      <div className='mt-3'></div>
    </div>
  )
}
